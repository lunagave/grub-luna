# grub-luna

Proyecto nuevo, desde cero, como Luna. Privado por ahora, solo Fernando y Muse.
Basado en grub-customizer solo como información. Créditos a Daniel Richter, autor original de grub-customizer.

## Lo más importante

Que el usuario nuevo NO pierda su GRUB. Con un solo botón lo recupera y lo deja como nuevo, como si nada hubiera pasado. Fernando tuvo que reinstalar su distro por culpa del GRUB, eso no debe pasar con grub-luna.

- Copia de seguridad automática antes de cambiar nada.
- Botón "Restaurar GRUB" que lo deja como estaba.
- Nunca romper el arranque.

## Objetivo - Paso 1

Que lea todos los archivos de GRUB.

Archivos que debe leer:
- /etc/default/grub
- /etc/grub.d/
- /boot/grub/grub.cfg
- /boot/grub/themes/ (si hay)
- /etc/grub.d/40_custom y demás scripts

## Reglas

- No tocar Luna. Luna queda fija hasta la v2.
- No tocar el GRUB real todavía, solo leer.
- Cada proyecto en su propio repositorio, con su comando fácil de Arch.
- Autor original de grub-customizer se conserva si se usa su código; Fernando es autor de la versión mejorada.

Hecho por Vega & Kiki
Guzman

#!/bin/bash
# grub-luna — instalador, 3 pasos, como Luna. Abre la ventanita si hay tkinter, si no zenity.
cd "$(dirname "$0")"
if python3 grub-luna-installer-gui.py 2>/dev/null; then exit 0; fi
if command -v zenity >/dev/null 2>&1; then
  zenity --info --no-markup --title="grub-luna" --text="grub-luna 0.1 — Instalador. Usa: python3 grub-luna-installer-gui.py"
else
  echo "grub-luna 0.1 — Instalador. Usa: python3 grub-luna-installer-gui.py"
fi

#!/bin/bash
set -e
mkdir -p grub-luna-deb/usr/bin grub-luna-deb/usr/share/applications grub-luna-deb/DEBIAN
cp grub-customizer-luna.py grub-luna-deb/usr/bin/grub-luna
chmod +x grub-luna-deb/usr/bin/grub-luna
cp grub-luna.desktop grub-luna-deb/usr/share/applications/
cat > grub-luna-deb/DEBIAN/control <<'EOF'
Package: grub-luna
Version: 0.1
Section: utils
Priority: optional
Architecture: all
Depends: python3, python3-tk, python3-pil, zenity, grub-common
Maintainer: Fernando <lunagave>
Description: Personaliza tu GRUB, fácil, sin perderlo nunca
EOF
dpkg-deb --build grub-luna-deb grub-luna_0.1_all.deb
echo "Listo: grub-luna_0.1_all.deb"

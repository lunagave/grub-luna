#!/usr/bin/env python3
"""grub-luna — instalador en 3 pasos, como Luna.
Paso 1: Instalar Arch Pacman / .deb Debian Ubuntu.
Paso 2: proceso con barrita morada animada, despacio.
Paso 3: Continuar — Abrir grub-luna.
Sin contraseña en terminal: makepkg sin -i y pkexec pacman -U en Arch;
en Debian/Ubuntu, pkexec dpkg -i. Nunca finge un éxito.
Uso: python3 grub-luna-installer-gui.py [--demo]
Hecho por Vega & Kiki / Guzman
Crédito: basado en grub-customizer solo como información, Daniel Richter.
"""
import argparse, shutil, subprocess, sys, threading, tkinter as tk
from pathlib import Path
from tkinter import messagebox
try:
    from PIL import Image, ImageTk
    PIL = True
except Exception:
    PIL = False

VERSION = "0.1"
BASE = Path(__file__).resolve().parent
FONDO = "#1e1033"; TARJETA = "#2d1b4e"; MORADO = "#7c3aed"; HOVER = "#8b5cf6"
CLARO = "#a78bfa"; VIVO = "#a855f7"; TEXTO = "#ffffff"; SUAVE = "#d8b4fe"; VERDE = "#22c55e"
IMG1 = "media-generation-grub-luna-instalador-paso1-gat-0-495f56c1-d29f-4f76-b53d-2d01f8e39382.webp"
IMG2 = "media-generation-grub-luna-instalador-paso2-0-3d175b6d-011a-4cb3-b1cd-a42609e09cbe.webp"
IMG3 = "media-generation-grub-luna-instalador-paso3-0-18937017-82fd-44d6-a909-795352141355.webp"

def cargar(ruta, w, h):
    if not PIL or not ruta or not ruta.is_file():
        return None
    try:
        img = Image.open(str(ruta)); img.thumbnail((w, h)); return ImageTk.PhotoImage(img)
    except Exception:
        return None

def boton(p, t, c, grande=False):
    return tk.Button(p, text=t, command=c, bg=MORADO, fg=TEXTO, activebackground=HOVER,
        activeforeground=TEXTO, relief="flat", borderwidth=0, padx=16, pady=12 if grande else 8,
        font=("sans-serif", 13, "bold") if grande else ("sans-serif", 11, "bold"), cursor="hand2")

class Instalador:
    def __init__(self, v, demo=False):
        self.v = v; self.demo = demo; self._imgs = []; self.metodo = None; self.ok = None; self._val = 0; self._job = None; self._lista = False
        v.title("grub-luna — Instalador"); v.configure(bg=FONDO); v.geometry("800x940"); v.resizable(False, False)
        self.p1 = tk.Frame(v, bg=FONDO); self.p2 = tk.Frame(v, bg=FONDO); self.p3 = tk.Frame(v, bg=FONDO)
        self._paso1(); self._paso2(); self._paso3(); self._mostrar(self.p1)

    def _mostrar(self, m):
        for x in (self.p1, self.p2, self.p3): x.pack_forget()
        m.pack(fill="both", expand=True)

    def _img(self, p, nombre, w, h, fb):
        f = cargar(BASE / nombre, w, h)
        if f: self._imgs.append(f); tk.Label(p, image=f, bg=FONDO).pack(pady=8); return
        tk.Label(p, text=fb, bg=TARJETA, fg=SUAVE, font=("sans-serif", 11), padx=12, pady=20).pack(pady=8, fill="x", padx=20)

    def _paso1(self):
        tk.Label(self.p1, text="GRUB-LUNA", bg=FONDO, fg=TEXTO, font=("sans-serif", 28, "bold")).pack(pady=(16, 0))
        tk.Label(self.p1, text=f"grub-luna {VERSION} — Paso 1 de 3", bg=FONDO, fg=SUAVE, font=("sans-serif", 12)).pack()
        tk.Label(self.p1, text="Personaliza tu GRUB, fácil, sin perderlo nunca.", bg=FONDO, fg=TEXTO, font=("sans-serif", 11)).pack(pady=(4, 0))
        self._img(self.p1, IMG1, 720, 500, "Póster grub-luna — gatito morado en la luna")
        tk.Label(self.p1, text="¿Cómo quieres instalar grub-luna?", bg=FONDO, fg=TEXTO, font=("sans-serif", 13, "bold")).pack(pady=(6, 8))
        b = tk.Frame(self.p1, bg=FONDO); b.pack(fill="x", padx=20)
        boton(b, "🟡\nInstalar Arch Pacman", lambda: self.elegir("pacman"), True).pack(side="left", expand=True, fill="both", padx=4)
        boton(b, "🌀\nInstalar .deb Debian Ubuntu", lambda: self.elegir("deb"), True).pack(side="right", expand=True, fill="both", padx=4)
        tk.Label(self.p1, text="Hecho por Vega & Kiki\nGuzman", bg=FONDO, fg=SUAVE, font=("sans-serif", 11)).pack(side="bottom", pady=14)

    def _paso2(self):
        tk.Label(self.p2, text="Paso 2 de 3", bg=FONDO, fg=SUAVE, font=("sans-serif", 12)).pack(pady=(24, 0))
        tk.Label(self.p2, text="Instalando grub-luna...", bg=FONDO, fg=TEXTO, font=("sans-serif", 26, "bold")).pack(pady=(8, 0))
        self.et_metodo = tk.Label(self.p2, text="", bg=FONDO, fg=SUAVE, font=("sans-serif", 14)); self.et_metodo.pack(pady=(8, 12))
        self._img(self.p2, IMG2, 640, 320, "Instalando grub-luna... por favor espera")
        self.barra = tk.Canvas(self.p2, width=640, height=36, highlightthickness=0, bg=FONDO); self.barra.pack(pady=24, padx=40)
        self.et_pct = tk.Label(self.p2, text="0%", bg=FONDO, fg=CLARO, font=("sans-serif", 48, "bold")); self.et_pct.pack(pady=(8, 0))
        self.et_estado = tk.Label(self.p2, text="Preparando...", bg=FONDO, fg=SUAVE, font=("sans-serif", 13), wraplength=640); self.et_estado.pack(pady=12)
        self._dibujar_barra()

    def _dibujar_barra(self):
        self.barra.delete("all")
        self.barra.create_rectangle(2, 2, 638, 34, fill=TARJETA, outline=CLARO, width=2)
        w = int(636 * self._val / 100)
        if w > 4: self.barra.create_rectangle(3, 3, 3 + w, 33, fill=VIVO, outline="")

    def _paso3(self):
        tk.Label(self.p3, text="Paso 3 de 3 — Finalizar", bg=FONDO, fg=SUAVE, font=("sans-serif", 12)).pack(pady=(12, 0))
        tk.Label(self.p3, text="¡Instalación completa!", bg=FONDO, fg=VERDE, font=("sans-serif", 30, "bold")).pack(pady=(4, 0))
        tk.Label(self.p3, text="grub-luna ya está instalado. Pulsa Continuar para abrir el programa.", bg=FONDO, fg=TEXTO, font=("sans-serif", 14)).pack(pady=(4, 8))
        self._img(self.p3, IMG3, 700, 500, "Instalación completa — 100%")
        self.et_res = tk.Label(self.p3, text="", bg=FONDO, fg=SUAVE, font=("sans-serif", 11), wraplength=440); self.et_res.pack(pady=6)
        boton(self.p3, "▶  Continuar — Abrir grub-luna", self.abrir, True).pack(pady=8, padx=20, fill="x")
        tk.Button(self.p3, text="Cerrar", command=self.v.destroy, bg=TARJETA, fg=TEXTO, relief="flat", padx=12, pady=8, font=("sans-serif", 11), cursor="hand2").pack(pady=4, padx=20, fill="x")
        tk.Label(self.p3, text="Hecho por Vega & Kiki\nGuzman", bg=FONDO, fg=SUAVE, font=("sans-serif", 11)).pack(side="bottom", pady=14)

    def elegir(self, m):
        self.metodo = m; self.et_metodo.config(text="Pacman — Arch / Garuda" if m == "pacman" else ".deb — Debian / Ubuntu")
        self._mostrar(self.p2); self._val = 0; self._lista = False; self._dibujar_barra(); self.et_pct.config(text="0%")
        self._tick(); threading.Thread(target=self._instalar, daemon=True).start()

    def _tick(self):
        if self._lista: return
        if self._val < 90:
            self._val += 1; self._dibujar_barra(); self.et_pct.config(text=f"{self._val}%")
            self.et_estado.config(text=f"Cargando{'.' * (1 + (self._val // 10) % 3)} Instalando grub-luna...")
        self._job = self.v.after(700, self._tick)

    def _correr(self, cmd):
        try: return subprocess.run(cmd, cwd=str(BASE), capture_output=True, text=True, timeout=600).returncode
        except Exception as e: print(f"grub-luna: {e}"); return 1

    def _instalar(self):
        if self.demo:
            import time; time.sleep(12); self.ok = True; self._fin("Demo: barrita del 1 al 100 sin instalar nada."); return
        if self.metodo == "pacman":
            if shutil.which("makepkg") and (BASE / "PKGBUILD").is_file():
                if self._correr(["makepkg", "--noconfirm"]) != 0: self.ok = False; self._fin("makepkg falló al compilar. Revisa la terminal."); return
                pkgs = sorted(BASE.glob("grub-luna-*.pkg.tar.zst"))
                if not pkgs: self.ok = False; self._fin("makepkg compiló, pero no dejó el paquete."); return
                ok = self._correr(["pkexec", "pacman", "-U", "--noconfirm", str(pkgs[-1])]) == 0 if shutil.which("pkexec") else self._correr(["makepkg", "-si", "--noconfirm"]) == 0
                self.ok = ok; self._fin("Instalado con Pacman." if ok else "No se pudo instalar. Revisa la terminal."); return
            self.ok = False; self._fin("makepkg no está aquí (esta no es Arch). Se mostró la barrita, pero no se instaló nada."); return
        if shutil.which("dpkg") and (BASE / "build-deb.sh").is_file():
            if self._correr(["bash", "build-deb.sh"]) == 0:
                debs = sorted(BASE.glob("grub-luna_*.deb"))
                if debs:
                    ok = self._correr(["pkexec", "dpkg", "-i", str(debs[-1])]) == 0 if shutil.which("pkexec") else self._correr(["sudo", "dpkg", "-i", str(debs[-1])]) == 0
                    self.ok = ok; self._fin("Instalado con .deb." if ok else "dpkg falló. Revisa la terminal."); return
            self.ok = False; self._fin("No se pudo compilar el .deb."); return
        self.ok = False; self._fin("dpkg / build-deb.sh no están aquí. Se mostró la barrita, pero no se instaló nada.")

    def _fin(self, msg):
        self._lista = True
        if self._job:
            try: self.v.after_cancel(self._job)
            except Exception: pass
        self._val = 100; self._dibujar_barra(); self.et_pct.config(text="100%"); self.et_res.config(text=msg); self._mostrar(self.p3)

    def abrir(self):
        gui = BASE / "grub-customizer-luna.py"
        if shutil.which("grub-luna"): subprocess.Popen(["grub-luna"])
        elif gui.is_file(): subprocess.Popen([sys.executable, str(gui)])
        else: messagebox.showinfo("grub-luna", "grub-luna instalado. Usa: grub-luna")
        self.v.destroy()

def main():
    a = argparse.ArgumentParser(); a.add_argument("--demo", action="store_true"); args = a.parse_args()
    v = tk.Tk(); Instalador(v, demo=args.demo); v.mainloop(); return 0
if __name__ == "__main__":
    raise SystemExit(main())

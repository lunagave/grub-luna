#!/usr/bin/env python3
# Grub-customizer-luna v0.1 - Paso 1 y 2
# Lee TODOS los archivos de GRUB, solo lectura, no cambia nada.
# Hecho por Vega & Kiki / Guzman
import os
import tkinter as tk
from tkinter import ttk, scrolledtext

VERSION = "0.1"

RUTAS = [
    "/etc/default/grub",
    "/boot/grub/grub.cfg",
    "/etc/grub.d/",
    "/boot/grub/themes/",
]

def leer_archivo(ruta):
    try:
        with open(ruta, "r", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"No se pudo leer: {e}"

def listar_carpeta(ruta):
    try:
        archivos = sorted(os.listdir(ruta))
        texto = ""
        for a in archivos:
            p = os.path.join(ruta, a)
            texto += f"{a}\n"
        return texto
    except Exception as e:
        return f"No se pudo leer: {e}"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Grub-customizer-luna {VERSION}")
        self.geometry("900x600")
        self.configure(bg="#1a0b2e")
        tk.Label(self, text="GRUB-CUSTOMIZER-LUNA", fg="#c084fc",
                 bg="#1a0b2e", font=("Arial", 22, "bold")).pack(pady=10)
        tk.Label(self, text="Paso 1: lee todos los archivos de GRUB  |  Paso 2: interfaz con toda la información  |  Solo lectura, no cambia nada",
                 fg="white", bg="#1a0b2e", font=("Arial", 10)).pack()
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=10, pady=10)
        for ruta in RUTAS:
            frame = ttk.Frame(nb)
            nb.add(frame, text=ruta)
            txt = scrolledtext.ScrolledText(frame, bg="#0f0518", fg="#e9d5ff",
                                            font=("monospace", 10))
            txt.pack(fill="both", expand=True)
            if os.path.isdir(ruta):
                txt.insert("1.0", listar_carpeta(ruta))
            else:
                txt.insert("1.0", leer_archivo(ruta))
            txt.config(state="disabled")
        tk.Label(self, text="Hecho por Vega & Kiki\nGuzman",
                 fg="#c084fc", bg="#1a0b2e").pack(pady=5)

if __name__ == "__main__":
    App().mainloop()
